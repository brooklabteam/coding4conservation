#######################################
## Introduction 
#######################################
## Compartmental models and differential equation R tutorial
##  Part II/II
## E2M2 - 2020
## written by: Jessica Metcalf, Amy Wesolowski, Cara Brook
## modified by: Katie Gostic

## In this tutorial, we will learn to use R's built-in ODE solver, lsoda
##  to solve continuous time models.
##
## 1. Solve a model for simple population growth three ways:
##  1.1 Exactly, using the state equation for exponential growth: N(t) = N0*exp(rt)
##  1.2 Iteratively, using a discrete-time approximation to the continuous model (Euler integration)
##  1.3 Exactly, using the lsoda ODE solver
##
## 2. Use lsoda to simulate a predator-prey model
##
## 3. Use lsoda to simulate an SIR model
##
## 4. Modify the SIR model to include a latent class


########################################################################
##   Simple population growth in continuous time
########################################################################

## ------------------------------------------------------------------
## 1.1 Solve exactly, using the state equation for exponential growth

## Recall from Monday that the equation for continuous-time growth of a simple population is:
##  N(t) = N0*exp(rt)
## Because we can solve this equation directly, the easiest way to model continuous time growth is to solve directly:
N0 = 10
r = log(lambda) 
t = 0:100
N_exact = N0*exp(r*t) 
N_exact


## Plot the results
plot(x=t, 
     y=N_exact, 
     col = 'orange', # set the color
     type = 'b', # plot a line
     xlab = 'time (in years)',
     ylab = 'Nt (population size)') 
legend(x = 10, 
       y = 100000, 
       legend = c('Continuous state equation: N(t)=N0*exp(rt)'), 
       col = c('orange'), 
       lty = c(1))

## ------------------------------------------------------------------
##  1.2 Iteratively, using a discrete-time approximation to the continuous model (Euler integration)
##
## We know that the instantaneous rate of change is:
##  dN/dt = rN
## We can solve iteratively using a discrete-time approximation to the continuous model (Euler integration)
##  As an analogy, if you were driving a car at 100km per hour, we could estimate that after 6 minutes, you had 
##  traveled 10km.
##  In this example, your instantaneous rate of change, dx/dt = 100km/hr, and you have been driving for 0.1 hr.
##   Your position after 0.1 hours, x(0.1) is equal to your initial position (x0), plus the number of km traveled:
##  x(0.1) = x0 + 100km/hr * 0.1hr = x0 + 10km
##
## You probably didn't drive exactly 100km per hour the entire time, so the above equation is an approximation of your
##  position after driving for 0.1h.
## We could make this approximation more accurate if we re-calculated your position every 1m instead of every 6m. 
## In general, using a smaller timestep gives a more accurate approximation, but smaller timesteps are computationally costly.
## If we choose a timestep that is too small, our code can take minutes or hours to run, or we can crash the computer.
##
## In general, we can use Euler integration to solve differential equations using the following formula:
## dt is the size of the time step
## dN/dt is the instantaneous rate of change at time t
## N(t+dt) =*approximately*= N(t) + dN/dt * dt
## In words this equation says:
## "The population size at the next timestep (t+dt) is equal to the population size at this timestep (N(t)) plus the change in the size of the population over the next timestep (dN/dt*dt). The change in the size of the population depends on the instantaneous rate of change at time t (dN/dt), and the time elapsed (dt).
##
## Let's apply this to our population growth model
## Start with the timestep from t=0 to t= 0.1
Pop = N0 ## Pop = N_t
delta.t <- 0.1    # Set a small value for delta.t (0.1 year)
## Let Pop_next represent N_t+1
dNdt = function(r, N){r*N} ## Write a function that calculates the derivative, given N, r
pop.next <- Pop + dNdt(r, N=Pop) * delta.t
pop.next

## We could iterate this process, updating our values of Pop 
## and time with each iteration to get a discrete-time approximation 
## of the values of $P$ through time:
times = seq(0, 100-delta.t, by = delta.t) ## Get a vector of times: 0.1, 0.2,0.3, ... 100
N_discrete_approximation = vector(length = length(times), mode = 'numeric') ## Create an empty vector to store N values
N_discrete_approximation[1] = 10 # Set the initial value equal to 10
## Use a for loop to calculate the population size at each timestep from 0.1 to 100
for(step in 2:length(times)){
  N_t = N_discrete_approximation[step-1]
  N_next = N_t + (delta.t*dNdt(r, N=N_t))
  N_discrete_approximation[step] = N_next
}
## Look at the results
discrete_approx = data.frame(t = times,
                             N = N_discrete_approximation)
head(discrete_approx)





## Add the discrete approximation to the plot
lines(x = discrete_approx$t, y = discrete_approx$N, col = 'magenta')
legend(x = 10, 
       y = 100000, 
       legend = c('Continuous state equation: N(t)=N0*exp(rt)',
                  'Discrete approximation: dt = 0.1'), 
       col = c('orange', 'magenta'), 
       lty = c(1))

## We can see the error in the discrete approximation by comparing the discrete approximation to the
## exact solution from the continous state equation.
## The discrete approximation is close, but not exactly equal to the exact solution 
##  from the state equation for exponential growth.
##It turns out that using the discrete time approximation 
## of this process leads to rapid acummulation of error in our estimate of the state 
## variables through time, even if we set our value of delta.t to be very small. 




## Run another discrete approximation using a larger time step.
## Do you expect this example to be more or less accurate?
delta.t = 1 ## Increase the timestep to 1 year
times = seq(0, 100-delta.t, by = delta.t) ## Get a vector of times: 0.1, 0.2,0.3, ... 100
N_discrete_approximation = vector(length = length(times), mode = 'numeric') ## Create an empty vector to store N values
N_discrete_approximation[1] = 10 # Set the initial value equal to 10
## Use a for loop to calculate the population size at each timestep from 0.1 to 100
for(step in 2:length(times)){
  N_t = N_discrete_approximation[step-1]
  N_next = N_t + (delta.t*dNdt(r, N=N_t))
  N_discrete_approximation[step] = N_next
}
## Look at the results
discrete_approx_dt_1.0 = data.frame(t = times,
                             N = N_discrete_approximation)
head(discrete_approx)

## Add the discrete approximation to the plot
lines(x = discrete_approx_dt_1.0$t, y = discrete_approx_dt_1.0$N, col = 'blue')
legend(x = 10, 
       y = 100000, 
       legend = c('Continuous state equation: N(t)=N0*exp(rt)',
                  'Discrete approximation: dt = 0.1',
                  'Discrete approximation: dt = 1.0'), 
       col = c('orange', 'magenta', 'blue'), 
       lty = c(1))

## Increasing the timestep made the accuracy of the discrete approximation much worse!
##
##
##
## On your own:
## See how small you can make the timestep before your computer starts to run slowly. 
## You can use scientific notation, e.g.: `delta.t = 10^-12`
## Does this increase the accuracy?



## Instead of using discrete approximations to solve compartmental models,
## we usually use an ODE solver called lsoda, from the deSolve package.
## Essentially, lsoda solves the differential equation using an approach similar to
##  our discrete approximation.
##  But lsoda is designed so that the program automatically re-calculates the size of the timestep
##  at each iteration in a way that balances accuracy and computational speed.
##  As a result, the solutions from lsoda are guaranteed to be fast, and at least as accurate as our discrete approximation.
##  We don't have to choose a timestep, but in order to use lsoda, we do have to write a function that evaluates
##  the derivative as a function of the state variables and paramters.
##  This function needs to be written in a very specific format, or the lsoda solver won't work.

##  Below, we'll work through an example using the lsoda ODE solver.
##  Note: ODE stands for "ordinary differential equation"
##        dN/dt = rN is an ordinary differential equation
##        "differential equation" means that the left-hand side is a derivative (a rate of change)
##        "ordinary" means that there is only one independent variable in the equation. Here, and in 
##         most compartmental models, the dependent variable is time (dt).

## First, write the differential equation dN(t)/dt = rN in a function
## called 'ngrow'


## In order for lsoda to work, the function MUST have three arguments:
##  t, a variable that lets lsoda keep track of the timestep
##  y, a named vector of state variables. In this example, our only state variable is N, so we will always input:
##     y = c('N' = VALUE)  # This is a vector called "y", containing one value with the assigned name N.
## params, a named vector of parameters. In this example, we will input:
##     params = c("r" = VALUE)
dNdt_lsoda <- function(t,y,parms){
  ## Parameters
  r = parms['r'] # Extract the value of r from the named vector, parms
  ## State variables
  N = y['N'] # Extract the value of N from the named vector, y
  dNdt <- r*N   # calculate the derivative
  names(dNdt) = 'dNdt'
  return(list(dNdt)) # The returned value MUST be in a list
}


## To solve this, we're going to need to use the R library called "deSolve".
## We also need to define the starting variables and parameters: 

library(deSolve)              # Load libary to be used for numerical integration
Pop <- c(N=10)                # Define starting variables (P(0)=10, as above)
values <- c(r=log(1.1))    # Define parameters - use an approx of the lambda used in the discrete time ex above
time.out <- seq(0,100,by=0.1) # Set up time-steps for variables - here go for 100 years
dNdt_lsoda(t=0,y=Pop,parms=values)  # Test the function: evaluate dNdt at t=0, with an initial population size of 10, and r = log(1.1)

## The function outputs the time derivative of N at the time t. 
# This means that in order to get the (approximate) values of N at some time 
# delta.t in the future, we need to calculate the equivalent of N(t+delta.t)=N(t)+rN(t)*delta.t. 


## Now use the function "lsoda()", along with the dNdt_lsoda function
## to solve for N(t) at every timestep in the vector times.out.
## Store the result in a variable called 'Ncontinuous': 


## Use the ODE solver
Ncontinuous <- lsoda(
  y = Pop,               # Initial conditions for population
  times = time.out,      # Timepoints for evaluation
  func = dNdt_lsoda,          # Function to evaluate
  parms = values         # Vector of parameters
)

## We can check the first few lines of the output:
head(Ncontinuous)

## The data frame has 2 columns showing the values of time (labeled "time") 
## and the state variable ("N", which is population size) through time. Let's see what 
## has happened after 2 years, by printing it out:
subset(Ncontinuous,time==2)

## Now we can also plot the full time-series: 
## Plot the lsoda solution
lines(Ncontinuous[,"time"],      # Time on the x axis
     Ncontinuous[,"N"],
     col = 'black')                # Plot a line
legend(x = 10, 
       y = 100000, 
       legend = c('Continuous state equation: N(t)=N0*exp(rt)',
                  'Discrete approximation: dt = 0.1',
                  'Discrete approximation: dt = 1.0',
                  'ODE solver, lsoda()'), 
       col = c('orange', 'magenta', 'blue', 'black'), 
       lty = c(1))


# The solution from the ODE solver lsoda() exactly matches the solution from the state equation for exponential growth!
## In the future, we'll always use lsoda() to solve ODE models.


## ON YOUR OWN: 
#### 1) See what happens to a population where r<0
#### 2) Change the time resolution (set by "time.out"") 
####   and see if/where the results change




##############################################################################
## 2. Use lsoda to simulate a Lotka-Volterra predator-prey model
##############################################################################

## Moving beyond considering just one species, a classic dynamic is that of predator-prey cycles. To caricature the process, we can imagine that fossa eat lemurs, until there aren't enough lemurs. Then the fossa population crashes, which allows the lemur population to grow again, etc. We can frame this in continuous time with the following equation:


## Just like in the simple population growth model, the first step to using lsoda
## is to write a function that evaluates the derivative for each state variable.
## The function must have three arguments:
## t - timepoints at which to calculate N(t)
## states - a named vector of state variables, and their values
## pars - a named vector of paramters and their values
predator_prey <- function (t, states, pars) {
  ## Extract state variables from the named vector, states
  x = states['x']
  y = states['y']
  ## Extract parameter values from the named vector, pars
  alpha = pars['alpha']
  beta = pars['beta']
  gamma = pars['gamma']
  delta = pars['delta']
  ## Calculate the derivatives for each state variable
    dx = x*(alpha - beta*y)
    dy = -y*(gamma - delta*x)  #reverse to just echo the line above :)
    return(list(c(dx, dy))) ## return as a list
}

## where x reflects the prey population (hares, rabbits, lemurs, etc), 
## and y reflects the predator population (wolves, foxes, fossa, etc). 
## The prey population grows at a linear rate (alpha) and gets eaten by the predator 
## population at the rate of (beta) per predator. The predator gains a certain amount 
## vitality by eating the prey at a rate (delta), while dying off at another rate (gamma). 
## Let's set some initial parameter values, and a starting population structure, and 
## time-vector, as previously: 

Pars.input <- c(alpha = 2, beta = .5, gamma = .2, delta = .6)
States.input <- c(x = 10, y = 10)
Times.input <- seq(0, 150, by = 1)

## Use lsoda to run the model. Store the results in a data frame called predator_prey_out
predator_prey_out <- as.data.frame(lsoda(func = predator_prey, 
                           y = States.input, 
                           parms = Pars.input, 
                           times = Times.input)) #run model
head(predator_prey_out) ## Look at the outputs

## plot results
matplot(x = predator_prey_out[,'time'], 
        y = predator_prey_out[,-1], 
        type = "l",    #separate 1st col (time), plot against other 2
        xlab = "time", ylab = "population", lty=1)  
legend("topright", c("Lemurs", "Fossa"), lty = c(1,1), col = c(1,2), box.lwd = 0)

## We can start with different starting numbers of rabbits and fosa, and overlay the two plots (using the command 'add=TRUE' in matplot). To distinguish the two runs, we use dashed lines for the second set of starting values using lty=2 (colours still represent predator and prey, as in the legend):  

States.input.2 <- c(x = 5, y = 10)
predator_prey_out.2 <- as.data.frame(lsoda(func = predator_prey, 
                                           y = States.input.2, 
                                           parms = Pars.input, 
                                           times = Times.input))
matplot(x = predator_prey_out[,'time'], 
        y = predator_prey_out[,-1], 
        type = "l",   
        xlab = "time", ylab = "population", lty=1)    #plot out our previous results
matplot(predator_prey_out.2[,1], predator_prey_out.2[,-1], type = "l", lty=2,add=TRUE)  #add the new runs
legend("topright", c("Lemurs", "Fossa"), lty = c(1,1), col = c(1,2), box.lwd = 0)

## This shows the same pattern, just slightly lagged in time. 
## After the initial transient (detectable by slightly higher or lower peaks for the 
## first few cycles), the two simulations start repeating the same pattern over and over. 

## We can try the same with different parameters, to understand what the parameters do, 
## again overlaying the new results for comparison. Here, we double the parameter alpha, 
## which determines prey reproduction: 

Pars.input.2 <- c(alpha = 4, beta = .5, gamma = .2, delta = .6)
predator_prey_out.pars2 <- as.data.frame(ode(func = predator_prey, 
                                               y = States.input, 
                                             parms = Pars.input.2, 
                                             times = Times.input))
matplot(predator_prey_out[,1],predator_prey_out[,-1], type = "l", 
        xlab = "time", ylab = "population", lty=1)  
  matplot(predator_prey_out.pars2[,1],predator_prey_out.pars2[,-1], type = "l", lty=2,add=TRUE)  
legend("topright", c("Lemurs", "Fossa"), lty = c(1,1), col = c(1,2), box.lwd = 0)

## The two time-series settle down to different patterns. Interestingly, if more lemurs
## are being produced, you end up with less lemurs in the end, because you are getting 
## more fossa in the system. Sometimes, this is referred to as the 'paradox of enrichment'. 


##############################################################################
## 3. Use lsoda to simulate an SIR model
##############################################################################

## Let's think about another two species model: dynamics for a directly 
## transmitted immunizing infection, with a short generation time (e.g., ~2 weeks), 
## like measles. We need to keep track of 3 states, or types of individuals, i.e., 
## susceptible individuals ('S'), infected individuals ('I') and recovered individuals ('R').
## We can write the function that defines this process, assuming that the total population 
## size is constant, which means we don't need to keep track of the ('R') compartment. 
## This is:  

sir_function <- function(t,states,parms){
  ## Extract state variables from named states vector
  S = states['S']
  I = states['I']
  R = states['R']
  N = S+I+R 
  ## Extract parameter values from named pars vector
  beta = parms['beta'] # transmission rate
  gamma = parms['gamma'] # recovery rate
  ## Evaluate the derivatives of each state variable with respect to t, params, states
  dSdt <- -beta*S*I/N
  dIdt <- beta*S*I/N - gamma*I
  dRdt <- gamma*I
  ## Return the results as a list
  list(c(dSdt,dIdt,dRdt))
}

## We define a starting population with 500,000 susceptible individuals and 20 infected 
## individuals; and a list of parameters that define the processes, beta, the transmission 
## rate, and gamma, the recovery rate (defined as 1/infectious period): 

states.input <- c(S = 500000, 
                  I = 20, 
                  R = 0)  
pars.input <- c(beta = 3.6,          # Transmission coefficient
            gamma = 1/5)            # recovery rate

## We can calculate the value of the basic reproduction number R_0 = beta / gamma, 
## as follows:

R0 <- values["beta"]/values["gamma"] # value of R0
R0                                  # Remember that the infection will spread (grow) 
#  when R0 > 1, just like the population grows when 
# lambda > 1 in the structured population models above.

## As in the population example, we can use the function lsoda, here taking as our time-unit
# 1 day, setting a small time-step, and running it out across 1 year (365 days): 
sir <- data.frame(lsoda(
  y = states.input,            # Initial conditions for population
  times = seq(0,365,by=0.1),   # Timepoints for evaluation
  func = sir_function,         # Function to evaluate
  parms = pars.input           # Vector of parameters
))

## Look at the resulting data frame from this run of the model pop.SI
head(sir)

## Make sure the total population size is constant over time
rowSums(sir[,c('S', 'I', 'R')])

## and then we can plot this: 
plot(sir[,"time"],sir[,"S"], xlab="Time", ylab="Susceptible", type="l", col = "blue")
lines(sir[,"time"],sir[,"I"], xlab="Time", ylab="Infected", type="l", col="red")
legend("topright", c("S", "I"), col = c("blue", "red"), lty=c(1,1),  box.lwd = 0)

## The epidemic burns itself out (i.e., at the end, the number of infected individuals 
## is zero), but, interestingly, not all susceptible individuals are infected (i.e., the 
## number of susceptibles at the end is > 0). This is the phenomenon of herd immunity. 

## Now we can re-run the analysis for a less infectious pathogen, i.e. beta is lower, but
## with the same population parameters:

lower.values <- c(beta = 0.9,   # Transmission coefficient decreases from 3.6 to .9
                  gamma = 1/5)         #recovery rate

lower.sir <- data.frame(lsoda(
  y = states.input,            # Initial conditions for population
  times = seq(0,365,by=0.1),   # Timepoints for evaluation
  func = sir_function,         # Function to evaluate
  parms = lower.values           # Vector of parameters
))

## and then we can plot this: 

plot(lower.sir[,"time"],lower.sir[,"S"], xlab="Time", ylab="Susceptible", type="l", col="blue", ylim = c(0, 5e5))
lines(lower.sir[,"time"],lower.sir[,"I"], xlab="Time", ylab="Infected", type="l", col="red")


## How are these results different? 

## On your own: 
#### 1) Change the parameter values to see what happens if people recover slower (lower gamma). 
#### 2) Change the number of initial infected individuals to 1 -- will the outbreak start earlier? Later? 
### 3) This model reflects a 'closed' population. There are \textbf{no new births} entering the population. Can you imagine how you might change the model to include this? What are the main dynamical consequences? 
### 4) You can download time-series for a number of infections including measles from https://www.tycho.pitt.edu; you could explore seasonality for different pathogens, or patterns through space and time, and across different city sizes  




##########################################################################
## 4. Modify the SIR model to include vaccination
##########################################################################

## Let mu represent the rate of progressing from exposed to infectious

## Hint:
## 1. Modify the states.input vector to include the new E state
## 2. Modify the pars.input vector to include the new mu parameter
## 3.Modify the sir_function(). Rename it to seir_function(), and update the function to
##   include the new paramter mu, the new state variable E, and a differential equation for the new state E. 
##   Remeber to output the new derivative E in the return list.
## 4. Modify the plotting code to include the E class



sir_function <- function(t,states,parms){
  ## Extract state variables from named states vector
  S = states['S']
  I = states['I']
  R = states['R']
  N = S+I+R 
  ## Extract parameter values from named pars vector
  beta = parms['beta'] # transmission rate
  gamma = parms['gamma'] # recovery rate
  ## Evaluate the derivatives of each state variable with respect to t, params, states
  dSdt <- -beta*S*I/N
  dIdt <- beta*S*I/N - gamma*I
  dRdt <- gamma*I
  ## Return the results as a list
  list(c(dSdt,dIdt,dRdt))
}


states.input <- c(S = 500000, 
                  I = 20, 
                  R = 0)  
pars.input <- c(beta = 3.6,          # Transmission coefficient
                gamma = 1/5)         # recovery rate


## and then we can plot this: 
plot(sir[,"time"],sir[,"S"], xlab="Time", ylab="Susceptible", type="l", col = "blue")
lines(sir[,"time"],sir[,"I"], xlab="Time", ylab="Infected", type="l", col="red")
legend("topright", c("S", "I"), col = c("blue", "red"), lty=c(1,1),  box.lwd = 0)



## Final notes
# Some of this material is extended from DAIDD and MMED courses. 


## References 

# Cawell, H. Matrix Population Models. 2001. Sinauer

# Salguero-Gomez, R., et al. The COMPADRE Plant Matrix Database: an open online repository for plant demography. Journal of Ecology, 2015. 103(1): p. 202-218.

